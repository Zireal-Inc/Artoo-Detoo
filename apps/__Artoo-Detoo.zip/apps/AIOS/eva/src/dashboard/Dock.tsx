import React from 'react';
import DockPanel from './panel/components/DockPanel'; // Import DockPanel

const Dock: React.FC = () => {
  const dockIcons = [
    { src: '/public/vite.svg', alt: 'Icon 1' },
    { src: '/public/vite.svg', alt: 'Icon 2' },
    { src: '/public/vite.svg', alt: 'Icon 3' },
  ];

  return (
    <nav className="dock">
      <DockPanel icons={dockIcons} /> {/* Render the DockPanel component */}
    </nav>
  );
};

export default Dock;