import React from 'react';

interface DockPanelProps {
  icons: { src: string; alt: string }[];
}

const DockPanel: React.FC<DockPanelProps> = ({ icons }) => {
  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 bg-black/50 rounded-xl p-2 z-1000 mb-2">
      <ul className="flex items-center list-none p-2 m-0">
        {icons.map((icon, index) => (
          <li className="mx-1" key={index}>
            <img src={icon.src} alt={icon.alt} className="w-8 h-8 transition-transform hover:scale-125" />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DockPanel;
