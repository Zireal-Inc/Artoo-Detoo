
import React from 'react';
import TopPanel from "./Panel"
const Panel: React.FC = () => {
  return (
    <header className="panel">
      {/* ...Mac OS-like header... */} 
      <TopPanel/>
    </header>
  );
};

export default Panel;