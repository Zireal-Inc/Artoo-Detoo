import {
    Menubar,
    MenubarCheckboxItem,
    MenubarContent,
    MenubarItem,
    MenubarMenu,
    MenubarRadioGroup,
    MenubarRadioItem,
    MenubarSeparator,
    MenubarShortcut,
    MenubarSub,
    MenubarSubContent,
    MenubarSubTrigger,
    MenubarTrigger,
} from "@ui/components/ui/menubar"

interface MenuItem {
    label: string
    shortcut?: string
    disabled?: boolean
    subMenu?: MenuItem[]
    type?: "separator" | "checkbox" | "radio"
    checked?: boolean
    value?: string
}

interface MenuSection {
    triggerLabel: string
    menuItems?: MenuItem[]
}

interface MenuPanelProps {
    menuSections?: { [key: string]: MenuSection }
}

export function MenuPanel({ menuSections }: MenuPanelProps) {

    const renderMenuItem = (item: MenuItem, level = 0) => {
        const inset = level > 0
        if (item.type === "separator") {
            return <MenubarSeparator key={"separator-" + level + "-" + Math.random()} />
        }

        if (item.type === "checkbox") {
            return (
                <MenubarCheckboxItem key={item.label} inset={inset} checked={item.checked}>
                    {item.label}
                </MenubarCheckboxItem>
            )
        }

        if (item.type === "radio") {
            return (
                <MenubarRadioItem key={item.label} inset={inset} value={item.value || ""}>
                    {item.label}
                </MenubarRadioItem>
            )
        }

        if (item.subMenu) {
            return (
                <MenubarSub key={item.label}>
                    <MenubarSubTrigger inset={inset}>{item.label}</MenubarSubTrigger>
                    <MenubarSubContent>
                        {item.subMenu.map(subItem => renderMenuItem(subItem, level + 1))}
                    </MenubarSubContent>
                </MenubarSub>
            )
        } else {
            return (
                <MenubarItem key={item.label} disabled={item.disabled} inset={inset}>
                    {item.label} {item.shortcut && <MenubarShortcut>{item.shortcut}</MenubarShortcut>}
                </MenubarItem>
            )
        }
    }

    const renderMenu = (menuItems: MenuItem[]) => {
        return menuItems?.map(item => renderMenuItem(item))
    }

    return (
        <Menubar>
            {Object.entries(menuSections || {}).map(([key, section]) => (
                <MenubarMenu key={key}>
                    <MenubarTrigger>{section.triggerLabel}</MenubarTrigger>
                    <MenubarContent>
                        {renderMenu(section.menuItems)}
                    </MenubarContent>
                </MenubarMenu>
            ))}
        </Menubar>
    )
}

export default MenuPanel;