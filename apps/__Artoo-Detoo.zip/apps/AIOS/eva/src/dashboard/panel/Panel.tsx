import React from 'react';
import MenuPanel from "./components/LeftPanel"
import CenterPanel from "./components/CenterPanel"
import RightPanel from "./components/RightPanel"

interface MenuItem {
    label: string
    shortcut?: string
    disabled?: boolean
    subMenu?: MenuItem[]
    type?: "separator" | "checkbox" | "radio"
    checked?: boolean
    value?: string
}

interface MenuSection {
    triggerLabel: string
    menuItems?: MenuItem[]
}

const defaultMenuSections: { [key: string]: MenuSection } = {
    file: {
        triggerLabel: "File",
        menuItems: [
            { label: "New Tab", shortcut: "⌘T" },
            { label: "New Window", shortcut: "⌘N" },
            { label: "New Incognito Window", disabled: true },
            {
                label: "Share",
                subMenu: [
                    { label: "Email link" },
                    { label: "Messages" },
                    { label: "Notes" },
                ],
            },
            { label: "Print...", shortcut: "⌘P" },
        ],
    },
    edit: {
        triggerLabel: "Edit",
        menuItems: [
            { label: "Undo", shortcut: "⌘Z" },
            { label: "Redo", shortcut: "⇧⌘Z" },
            { type: "separator" },
            {
                label: "Find",
                subMenu: [
                    { label: "Search the web" },
                    { type: "separator" },
                    { label: "Find..." },
                    { label: "Find Next" },
                    { label: "Find Previous" },
                ],
            },
            { type: "separator" },
            { label: "Cut" },
            { label: "Copy" },
            { label: "Paste" },
        ],
    },
    view: {
        triggerLabel: "View",
        menuItems: [
            { label: "Always Show Bookmarks Bar", type: "checkbox" },
            { label: "Always Show Full URLs", type: "checkbox", checked: true },
            { type: "separator" },
            { label: "Reload", shortcut: "⌘R" },
            { label: "Force Reload", shortcut: "⇧⌘R", disabled: true },
            { type: "separator" },
            { label: "Toggle Fullscreen" },
            { type: "separator" },
            { label: "Hide Sidebar" },
        ],
    },
    profiles: {
        triggerLabel: "Profiles",
        menuItems: [
            {
                label: "Profiles",
                subMenu: [
                    { label: "Andy", type: "radio", value: "andy" },
                    { label: "Benoit", type: "radio", value: "benoit" },
                    { label: "Luis", type: "radio", value: "Luis" },
                ],
            },
            { type: "separator" },
            { label: "Edit..." },
            { type: "separator" },
            { label: "Add Profile..." },
        ],
    },
}

const TopPanel: React.FC = () => {
    return (
        <header className="panel">
            {/* ...Mac OS-like header... */}
            <div className="flex flex-row justify-between items-center w-full">
                <MenuPanel menuSections={defaultMenuSections} />
                <CenterPanel />
                <RightPanel />
            </div>
        </header>
    );
};

export default TopPanel;