import React, { useState, useEffect } from 'react';
import {
    Menubar, 
    MenubarMenu, 
    MenubarTrigger,
} from "@ui/components/ui/menubar"

const CenterPanel: React.FC = () => {
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const intervalId = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);

        return () => clearInterval(intervalId);
    }, []);

    const formattedTime = currentTime.toLocaleTimeString();

    const options: Intl.DateTimeFormatOptions = {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
    };
    const formattedDate = currentTime.toLocaleDateString(undefined, options);

    return (
        <Menubar>  
                <MenubarMenu triggerLabel="Time">
                    <MenubarTrigger>{formattedDate} | {formattedTime}</MenubarTrigger> 
                </MenubarMenu> 
        </Menubar> 
    );
};

export default CenterPanel;
