import React from 'react';
import {
    Menubar,
    MenubarMenu,
    MenubarTrigger,
} from "@ui/components/ui/menubar"
import { Battery, Wifi, Power } from 'lucide-react';

const RightPanel: React.FC = () => {
    return (
        <Menubar>
            <MenubarMenu triggerLabel="System">
                <MenubarTrigger>
                    <Battery size={20} /> 
                </MenubarTrigger>
                <MenubarTrigger> 
                    <Wifi size={20} /> 
                </MenubarTrigger>
                <MenubarTrigger> 
                    <Power size={20} />
                </MenubarTrigger>

            </MenubarMenu>
        </Menubar>
    );
};

export default RightPanel;
