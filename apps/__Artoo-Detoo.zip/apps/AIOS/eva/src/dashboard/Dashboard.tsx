import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@ui/components/ui/card";
import Panel from './panel';
import Manager from './Manager';
import Dock from './Dock';

const Dashboard: React.FC = () => {
  return (
    <div className="dashboard-container">
      <Panel />
      <Manager />
      <Dock />
    </div>
  );
};

export default Dashboard;