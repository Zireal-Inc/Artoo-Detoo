import './App.css';
import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import NavMenu from './components/layout/Header';
import Footer from './components/layout/Footer';
import Home from './pages/home';
import SignIn from './auth/SignIn';
import SignUp from './auth/SignUp';
import AuthLayout from './components/layout/AuthLayout';
import React from 'react';
import { AuthProvider } from './contexts/AuthContext';
import Dashboard from './dashboard/Dashboard';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Auth routes */}
          <Route element={<AuthLayout />}>
            <Route path="/login" element={<SignIn />} />
            <Route path="/signup" element={<SignUp />} />
          </Route>

          {/* Main layout routes */}
          <Route path="/" element={
            <div className="min-h-screen flex flex-col">
              <NavMenu />
              <main className="flex-1">
                <Outlet />
              </main>
              <Footer />
            </div>
          }>
            <Route index element={<Home />} />
            <Route path="docs/*" element={<div>Documentation</div>} />
            {/* <Route path="/dashboard" element={<Dashboard />} /> */}
          </Route>

          {/* DashBoard  */}
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
