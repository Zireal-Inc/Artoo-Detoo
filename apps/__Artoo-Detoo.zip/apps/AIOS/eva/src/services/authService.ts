interface User {
    id: string;
    username: string;
    email: string;
    password: string;
}

class AuthService {
    private users: User[] = [];

    constructor() {
        this.init();
    }

    init() {
        try {
            const data = localStorage.getItem('users');
            this.users = data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('Error loading users:', error);
            this.users = [];
        }
    }

    private saveUsers() {
        localStorage.setItem('users', JSON.stringify(this.users));
    }

    async register(userData: Omit<User, 'id'>) {
        const existingUser = this.users.find(
            u => u.username === userData.username || u.email === userData.email
        );

        if (existingUser) {
            throw new Error('Username or email already exists');
        }

        const newUser = {
            ...userData,
            id: Date.now().toString(),
        };

        this.users.push(newUser);
        this.saveUsers();
        return newUser;
    }

    async login(username: string, password: string) {
        const user = this.users.find(
            u => u.username === username && u.password === password
        );

        if (!user) {
            throw new Error('Invalid credentials');
        }

        return user;
    }
}

export const authService = new AuthService();
