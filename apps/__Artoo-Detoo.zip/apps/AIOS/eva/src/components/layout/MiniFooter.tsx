export default function MiniFooter() {
  return (
    <footer className="py-4 text-center text-sm text-gray-500">
      <p>© {new Date().getFullYear()} EVA. All rights reserved.</p>
    </footer>
  );
}
