import React from 'react';
import { Outlet } from 'react-router-dom';
import MiniFooter from './MiniFooter';

function AuthLayout() {
    return (
        <div className="min-h-screen flex flex-col">
            <main className="flex-1">
                <Outlet />
            </main>
            <MiniFooter />
        </div>
    );
}


export default AuthLayout;