import React, { createContext, useContext, useEffect, useState } from 'react';

interface User {
  id: string;
  username: string;
  email: string;
  password: string;
}

interface AuthContextType {
  currentUser: User | null;
  register: (data: Omit<User, 'id'>) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);

  // Load existing users from public/data/users.json
  useEffect(() => {
    fetch('/data/users.json')
      .then(res => res.json())
      .then(json => {
        // The file should look like: { "users": [ ... ] }
        setUsers(json.users || []);
      })
      .catch(err => console.error('Failed to load users:', err));
  }, []);

  const register = async (userData: Omit<User, 'id'>) => {
    if (users.some(u => u.email === userData.email)) {
      throw new Error('Email already registered');
    }
    const newUser: User = {
      id: Math.random().toString(36).slice(2, 10),
      ...userData,
    };
    setUsers(prev => [...prev, newUser]);
  };

  const login = async (email: string, password: string) => {
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) {
      throw new Error('Invalid email or password');
    }
    setCurrentUser(user);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
