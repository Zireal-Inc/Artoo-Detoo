import { Button } from "@ui/components/ui/button";
import { Card } from "@ui/components/ui/card";
import Container from "../../components/shared/container";

export default function Home() {
  return (
    <Container>
      <div className="py-20 space-y-8">
        <h1 className="text-4xl font-bold text-center">Welcome to EVA</h1>
        <Card className="p-6 max-w-2xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4">Getting Started</h2>
          <p className="mb-4">This is your new EVA application built with modern tools and components.</p>
          <Button>Get Started</Button>
        </Card>
      </div>
    </Container>
  );
}
 