# App Creation

```sh
pnpm create vite <App-Name>
# if pnpm is install in locally 
npx pnpm create vite <App-Name>
```

## Setting up Tailwind CSS

1. Install Tailwind CSS and its dependencies:

```sh
pnpm add -D tailwindcss postcss autoprefixer
pnpm add -D tailwindcss-animate
pnpm dlx tailwindcss init -p
#or
npx tailwindcss init -p
```

2. Create a tailwind.config.js in your app:

```js
/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [
    require("../../../configs/tailwind-config/tailwind.config.base.js")
  ],
};
```

3. Add Tailwind directives to your CSS:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

## Including package/ui

1. Add the UI package to your app:

```sh
pnpm add @repo/ui
```

2. Import components from the UI package:

```tsx
import { Button, Card } from "@repo/ui";
```

3. Update your tsconfig.json to include the UI package path:

```json
{
  "compilerOptions": {
    "paths": {
      "@repo/ui": ["../../packages/ui/src"]
    }
  }
}
```

## Important Notes

- Ensure the relative paths in tailwind.config.js match your project structure
- The UI package must be built before it can be used in your app
- Run `pnpm build` in the UI package directory if you make changes
