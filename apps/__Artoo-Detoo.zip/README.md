# Artoo-Detoo
 Artoo-Detoo (R2-D2)
