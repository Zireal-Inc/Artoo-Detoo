
import { defineConfig } from 'vite';

export default defineConfig({
  // Vite configuration options
});