module.exports = {
    // Add your Prettier configuration here
    semi: true,
    singleQuote: true,
    trailingComma: 'es5',
    printWidth: 80,
    tabWidth: 2,
};
