
module.exports = {
  extends: [
    'plugin:react-native/all',
  ],
  rules: {
    // Add React Native-specific rules here
  },
};