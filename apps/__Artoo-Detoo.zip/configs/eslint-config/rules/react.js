
module.exports = {
  extends: [
    'plugin:react/recommended',
  ],
  settings: {
    react: {
      version: 'detect',
    },
  },
  rules: {
    // Add React-specific rules here
  },
};