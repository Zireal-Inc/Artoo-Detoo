/** @type {import('tailwindcss').Config} */
module.exports = {
	presets: [
		require("../../configs/tailwind-config/tailwind.config.base.js")
	],
};